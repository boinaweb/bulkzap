
var varWindow;
var urlSistema =  "http://sistema.appclientefiel.com.br";
//var urlSistema =  "http://52.86.148.125:8080/ClienteFiel/web";

(function() {
	
	console.log('Iniciando izza.js');
	
	setTimeout(autenticar,3000);


	

})();

function aguardarCookie() {
	try {
		console.log('aguardando cookie login...');

	} catch(e) {
		console.log(e);
	}	
	
	setTimeout(aguardarCookie(),3000);
}

function autenticar() {
	if (localStorage.getItem('chaveAcesso') != null) {
		window.WAPI.waitNewMessages(false,proccessMessage);
		window.serverMessage({ tipo: "login", chaveAcesso : localStorage.getItem('chaveAcesso')});
	} else {
		window.serverMessage({ tipo: "logout", chaveAcesso : ''});
	}
}

function mensagemFromBackground(data) {
	console.log("mensagemFromBackground -> " + JSON.stringify(data));

	if (data == null || data == undefined) {
		console.log("data is null -> mensagemFromBackground");
		return false;
	}

	switch(data.tipo) {
		  case "login":
		    criarDivLogada();
		    localStorage.setItem('chaveAcesso', data.chaveAcesso);
		    break;
		  case "logout":
		    criarDivDesLogada();
		    localStorage.removeItem('chaveAcesso'); 
		    break;
		  case "start":
		    localStorage.removeItem('pause'); 
		    criarDivLogada();
		    break;
		  case "stop":
		  	localStorage.setItem('pause', true);
		  	criarDivLogada();
		    break;
		  case "erro":
			console.log("erro: " + data);
		  	break;
		  case "text":
		  	enviarMensagem(data);
		    break;
		  default:
		    console.log("outros: " + data);
	}
}

function enviarMensagem(data) {
	if (localStorage.getItem('pause') == null) {
		switch(data.tipo) {
		  case "text":
		  	window.WAPI.sendMessageToID(data.numeroCelular, data.mensagem);	
		  	break;
		}	
	}
}

function criarDivLogada() {

	if (localStorage.getItem('pause') == null) {
		document.getElementById('divIzza').innerHTML = 'Izza Bot pronta para reponder às suas mensagens.&nbsp;&nbsp; ';
		document.getElementById('divIzza').style.backgroundColor = '#a237f487';
		var button = document.createElement('button');          
		var bText = document.createTextNode('Pausar Atendimento');          
		button.appendChild(bText);        
		button.onclick = stop;
		document.getElementById('divIzza').appendChild(button);
	} else {
		document.getElementById('divIzza').innerHTML = 'Izza Bot está com o envio de mensagens pausado.&nbsp;&nbsp; ';
		document.getElementById('divIzza').style.backgroundColor = '#f4b23b';
		var button = document.createElement('button');          
		var bText = document.createTextNode('Iniciar Atendimento');          
		button.appendChild(bText);        
		button.onclick = start;
		document.getElementById('divIzza').appendChild(button);
	}
	
}

function criarDivDesLogada() {
	document.getElementById('divIzza').innerHTML = 'Izza Bot não conectada.&nbsp;&nbsp; ';
	document.getElementById('divIzza').style.backgroundColor = '#ff4d4d';
	var button = document.createElement('button');          
	var bText = document.createTextNode('Fazer Login ');   
	button.appendChild(bText);        
	button.onclick=login;
	document.getElementById('divIzza').appendChild(button);
}



function proccessMessage(data) {
	console.log('Mensagem recebida: '+ data.length);

	if (localStorage.getItem('chaveAcesso') != null) {
		var i;
		for (i = 0; i < data.length; i++) { 
			//console.log(data[i]);
			window.serverMessage(data[i]);		
		}
	}
}

function conectar(chave) {
	console.log("Chave recebida do sistema adm: " + chave);
	localStorage.setItem('chaveAcesso', chave);
	varWindow.close();
	window.location.href=window.location.href;
}

function login() {
	varWindow = window.open (urlSistema, 'popup');
}

function start() {
	window.serverMessage({ tipo: "start", chaveAcesso : ''});
	window.location.href=window.location.href
}

function stop() {
	window.serverMessage({ tipo: "stop", chaveAcesso : ''});
	window.location.href=window.location.href
}

function logout() {
	if (confirm('Tem certeza que deseja desativar a Izza?')) {
		localStorage.removeItem('chaveAcesso'); 
		alert('Você parou a Izza!'); 
		var data = { chaveAcesso : ''};
		window.location.href=window.location.href;
		window.serverMessage(data);
	}
}
/*
This variable is responsible for keeping track of the active WhatsApp tab.
It is updated once the tab communicates with the background page (sends a type:start request)
*/
var numeroJanela = -1;
var whatsapp_tab_id = -1;
var pedidos_aba_id = -1;
var chaveAutenticacao;
var urlBase = "http://ws.appclientefiel.com.br/rest/";
var urlPedidos = "http://sistema.appclientefiel.com.br/web/controlepedidosfornecedor/ver";
var urlDominioSistema =  "http://sistema.appclientefiel.com.br";
//var urlBase = "http://52.86.148.125:8080/ClienteFiel/rest/";

chrome.notifications.onButtonClicked.addListener(atualizarPedido );


chrome.runtime.onStartup.addListener(function () {
	console.log("Plugin Startup");			

});

chrome.runtime.onInstalled.addListener(function () {
	console.log("Plugin instalado");
	 inicializarTabs();
	//setTimeout(inicializarTabs, 5000);
});


function inicializarTabs() {
	whatsapp_tab_id = -1;
	pedidos_aba_id = -1;
	numeroJanela = -1;
	var abas = new Array();

	chrome.windows.getCurrent(function(win) {
    	chrome.tabs.getAllInWindow(win.id, function(tabs) {
	        abas = tabs;
			console.debug(abas);

			var i;
			for (i = 0; i < abas.length; i++) {
				var aba = abas[i];
			    if (~aba.url.indexOf("web.whatsapp.com")) {
			    	whatsapp_tab_id = aba.id;
			    }

			    if (~aba.url.indexOf("sistema.appclientefiel.com.br")) {
			    	pedidos_aba_id = aba.id;
			    }
		  	}

		  	if (pedidos_aba_id == -1) {
				chrome.tabs.create({ url: urlDominioSistema, index : 0 });			
			} else {
				chrome.tabs.update(pedidos_aba_id,{url: urlDominioSistema});
			}

			if (whatsapp_tab_id == -1) {
				chrome.tabs.create({ url: 'https://web.whatsapp.com/', index : 1});
			} else {
				chrome.tabs.update(whatsapp_tab_id,{url:"https://web.whatsapp.com"});
			}

		});
	});
}
 

chrome.webNavigation.onCompleted.addListener(function(details) {

	/*Adiciona os scripts na página do whatsapp*/
	if (~details.url.indexOf("https://web.whatsapp.com/")) {
		console.log("Abriu a página web.whatsapp.com");	
		whatsapp_tab_id = details.tabId;
		chrome.tabs.executeScript(details.tabId, {file: "js/content.js"});
	}

	if (~details.url.indexOf("pedidosfornecedor")) {
		console.log("Abriu a página de recebimento dos pedidos");	
		pedidos_aba_id = details.tabId;
	}

	/*Obtém o cookie da página do cliente fiel*/
	if (~details.url.indexOf("52.86.148.125") || ~details.url.indexOf("sistema.appclientefiel.com.br")) {
		console.log("Abriu a página sistema.appclientefiel.com.br" );	
		if (whatsapp_tab_id != -1) {
			getCookieIZZA();
		} else {
			console.log('Página do whatsapp ainda não aberta.')
		}
	}

	
});


function removeCookieIZZA() {
	chrome.cookies.remove({"url": urlDominioSistema, "name": "CHAVEIZZAONLINE"}, function(cookie) {
        console.log("cookie removido: " + cookie)
    });
}

function getCookieIZZA() {
    chrome.cookies.get({"url": urlDominioSistema, "name": "CHAVEIZZAONLINE"}, function(cookie) {
	        if (cookie) {
		        ID = cookie.value;
		        var chaveAtual = localStorage.getItem('chaveAcesso');
		        console.log("chave salva:" + chaveAtual);
		        console.log("cookie lido:" + ID);
		        /*Caso a chave do cookie seja diferente da atual, atualiza a chave e reinicia a página do whatsapp*/
		        if (chaveAtual == null || chaveAtual != ID) {
		        	localStorage.setItem('chaveAcesso', ID);	
		        	clientMessage({tipo : "atualizar"});
		        }
		      }
	 });
}


/*
Passes a message to the client (dict-obj)
Full journey from here - to content script, then to the webpage through the DOM
*/
function clientMessage(data) {
	//console.log("clientMessage: ", JSON.stringify(data));
	chrome.tabs.sendMessage(whatsapp_tab_id, data);
}

/*
Listening to messages from the content script (webpage -> content script -> *backgrund page* -> host)
*/
chrome.runtime.onMessage.addListener(function(data, sender) {
	
	if (sender.tab) {
		
		switch(data.tipo) {
		  case "init":
		    console.log('Init recebido da página do whatsapp');
		    init();
		    break;
		  case "logout":
		    console.log('Logout recebido da página do whatsapp');
		    logout();
		    break;
		  case "start":
		  	console.log('Start recebido da página do whatsapp');
		    start();
		    break;
		  case "pause":
		    console.log('Pause recebido da página do whatsapp');
		    pause();
		    break;
		  default:
		    processMessage(data);
		}
	}
});

function isLoggedActive() {
	return localStorage.getItem('chaveAcesso') != null && localStorage.getItem('pause') == null;
}

function isLogged() {
	return localStorage.getItem('chaveAcesso') != null;
}



function requestServerPost(obj, path) {
	var ajax = new XMLHttpRequest();
	var url = urlBase + path;

	ajax.open("POST", url, true);
	ajax.setRequestHeader("Access-Control-Allow-Origin", "*");
	ajax.setRequestHeader("Access-Control-Allow-Headers", "Content-type");
	ajax.setRequestHeader("Content-type", "application/json");
	ajax.setRequestHeader("Authorization", "Basic " + localStorage.getItem('chaveAcesso'));
	ajax.send(JSON.stringify(obj));

	// Cria um evento para receber o retorno.
	ajax.onreadystatechange = function() {
	  // Caso o state seja 4 e o http.status for 200, é porque a requisiçõe deu certo.
	  
		if (ajax.readyState == 4) {
			if (ajax.status == 200) {
				var data = JSON.parse(ajax.responseText);			    
				console.log('Mensagem enviada ao servidor: ' + obj.idMensagem);
			    clientMessage(data);
			} else if (ajax.status == 401) {
				console.log('Chamando logout.');
				logout();	
			} else {
				console.log("Status:" + ajax.status);
				clientMessage(data);
			}
		} 
	}	
}

function processMessage(data) {
	if (isLoggedActive()) {
		if (data != null) {
			var obj = { 
			  "appNome"   :  "cliente_fiel", 
			  "numeroCelular"   :  data.chatId._serialized,
			  "mensagem"   :  data.content, 
			  "idMensagem"   :  data.id, 
			  "idRemetente"   :  data.to.user,
			  "nome" : data.sender.formattedName
			};
			requestServerPost(obj, 'bot/RegistrarMensagem');
		} else {
			console.log('processMessage data nulo: ' + data );
		}
	}
}

function init() {
	if (localStorage.getItem('chaveAcesso') != null && localStorage.getItem('pause') == null) {
		clientMessage({tipo : "logado"});
		
		var ajax = new XMLHttpRequest();
		var url = urlBase + "bot/ScriptInicial";
			
		ajax.open("GET", url, true);
		ajax.setRequestHeader("Access-Control-Allow-Origin", "*");
		ajax.setRequestHeader("Access-Control-Allow-Headers", "Content-type");
		ajax.setRequestHeader("Content-type", "application/json");
		ajax.setRequestHeader("Authorization", "Basic " + localStorage.getItem('chaveAcesso'));
		ajax.send();

		// Cria um evento para receber o retorno.
		ajax.onreadystatechange = function() {
		  // Caso o state seja 4 e o http.status for 200, é porque a requisiçõe deu certo.
			if (ajax.readyState == 4) {
				if (ajax.status == 200) {
					var lista = JSON.parse(ajax.responseText);
					var i;
					for (i = 0 ; i < lista.length;  i++) {
						console.log(lista[i]);
						clientMessage(lista[i]);			
					}			    
				} else if (ajax.status == 401) {
					console.log('chamando logout');
					logout();	
				} else {
					console.log("Status:" + ajax.status);
				}
			}
		}	
		setTimeout(sendWaitMessage,5000); ;	


	} else if (localStorage.getItem('chaveAcesso') != null && localStorage.getItem('pause') != null) {
		clientMessage({tipo : "pausado"});	
	} else {
		clientMessage({tipo : "deslogado"});
		waitLogin();
	}
}

function sendWaitMessage() {
	clientMessage({tipo : "aguardarmensagem"});
}

function waitLogin() {
	console.log("Aguardando login");
	
	try {
		getCookieIZZA();
		if (localStorage.getItem('chaveAcesso') != null) {
			console.log("Logado, atualizando tela.");
			clientMessage({tipo : "atualizar"});	
			return true;
		}
	}  catch(e) {
		console.log(e);
	}

	setTimeout(waitLogin,3000);
}

function start() {
	localStorage.removeItem('pause');
	clientMessage({tipo : "logado"});
}

function pause() {
	localStorage.setItem('pause', true);
	clientMessage({tipo : "pausado"});
}

function logout() {
	localStorage.removeItem('chaveAcesso');
	removeCookieIZZA();
	clientMessage({tipo : "deslogado"});
	waitLogin();
}



function getNewMessages() {
	try {
		if (isLoggedActive()) {
			//console.log('Buscando novas mensagens: ' + localStorage.getItem('chaveAcesso'));

			var ajax = new XMLHttpRequest();
			var url = urlBase + "bot/BuscarMensagem";
				
			ajax.open("GET", url, true);
			ajax.setRequestHeader("Content-type", "application/json");
			ajax.setRequestHeader("Authorization", "Basic " + localStorage.getItem('chaveAcesso'));
			ajax.send();

			// Cria um evento para receber o retorno.
			ajax.onreadystatechange = function() {
			  // Caso o state seja 4 e o http.status for 200, é porque a requisiçõe deu certo.
				if (ajax.readyState == 4) {
					if (ajax.status == 200) {
						var lista = JSON.parse(ajax.responseText);
						var i;
						for (i = 0 ; i < lista.length;  i++) {
							console.log(lista[i]);
							clientMessage(lista[i]);			
						}			    
					} else if (ajax.status == 401) {
						console.log('chamando logout');
						logout();	
					} else {
						console.log("Status:" + ajax.status);
					}
				}
			}	
		}
	} catch(e) {
		console.log(e);
	}

	setTimeout(getNewMessages, 5000);
}


function abrirAbaPedidos() {
	pedidos_aba_id = -1;
	var abas = new Array();

	chrome.windows.getCurrent(function(win) {
    	chrome.tabs.getAllInWindow(win.id, function(tabs) {
	        abas = tabs;
			console.debug(abas);

			var i;
			for (i = 0; i < abas.length; i++) {
				var aba = abas[i];
			    if (~aba.url.indexOf("pedidosfornecedor")) {
			    	pedidos_aba_id = aba.id;
			    }
		  	}

		  	if (pedidos_aba_id == -1) {
				chrome.tabs.create({index : 0, windowId : win.id,  url: urlPedidos });			
			} else {
				//(pedidos_aba_id,{active : true});
				//forçar a musica e impressão
			}

		});
	});
}

function getNewPedidos() {
	try {
		if (isLogged()) {
			//console.log('Buscando novos pedidos: ' + localStorage.getItem('chaveAcesso'));

			var ajax = new XMLHttpRequest();
			var url = urlBase + "integracao/eventspolling";
				
			ajax.open("GET", url, true);
			ajax.setRequestHeader("Content-type", "application/json");
			ajax.setRequestHeader("Authorization", "Basic " + localStorage.getItem('chaveAcesso'));
			ajax.send();

			// Cria um evento para receber o retorno.
			ajax.onreadystatechange = function() {
			  // Caso o state seja 4 e o http.status for 200, é porque a requisiçõe deu certo.
				if (ajax.readyState == 4) {
					if (ajax.status == 200) {
						var lista = JSON.parse(ajax.responseText);
						var i;
						for (i = 0 ; i < lista.length;  i++) {
							var n = lista[i];
							
							if (n.code == 'PLACED' && n.statusPedido == 0) {
								abrirAbaPedidos();
								
								var options =  {
													type: 'basic',
													title: 'Você tem um novo pedido #' + n.correlationId,
													message: 'Aceite pela página de pedidos no navegador.',
													iconUrl: 'logo/32.png',
													buttons: [{title : 'Aceitar'}]											
												};
								console.log("Solicitação: " + n.code);
								chrome.notifications.create('' + n.correlationId, options, function(data) {console.log('notify: ' + data);} );
							}
						}			    
					} else if (ajax.status == 401) {
						console.log('chamando logout');
						logout();	
					} else {
						console.log("Status:" + ajax.status);
					}
				}
			}	
		}
	} catch(e) {
		console.log(e);
	}

	setTimeout(getNewPedidos, 5000);
}


function atualizarPedido(notificationId, buttonIndex) {
	console.log('SolicitacaoId: ' + notificationId);
	console.log('button: ' + buttonIndex);
	if (buttonIndex == 0) {
		console.log('Aceitar Pedido');
		var ajax = new XMLHttpRequest();
		var url = urlBase + "integracao/orders/"+ notificationId + "/statuses/confirmation";
			
		ajax.open("POST", url, true);
		ajax.setRequestHeader("Content-type", "application/json");
		ajax.setRequestHeader("Authorization", "Basic " + localStorage.getItem('chaveAcesso'));
		ajax.send();

		// Cria um evento para receber o retorno.
		ajax.onreadystatechange = function() {
		  // Caso o state seja 4 e o http.status for 200, é porque a requisiçõe deu certo.
			if (ajax.readyState == 4) {
				if (ajax.status == 200) {
					console.log('atualizando notificacao');
					var options =  {
						type: 'basic',
						title: 'Pedido Aceito' ,
						message: 'Código do pedido #' + notificationId,
						iconUrl: 'logo/32.png',
						buttons : []
					};
					chrome.notifications.update('' + notificationId, options, function(data) {console.log('notify: ' + data);} );		    
				} else if (ajax.status == 401) {
					console.log('chamando logout');
					logout();	
				} else {
					console.log("Status Ajax:" + ajax.status);
				}
			}
		}	

	} else if (buttonIndex == 1) {
		console.log('Cancelar Pedido');

	} else {
		console.log('botão não identificado clicado.');
	}
}

(function() {
	getNewMessages();
	getNewPedidos();
})();
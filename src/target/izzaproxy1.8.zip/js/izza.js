
var varWindow;
var urlSistema =  "http://sistema.appclientefiel.com.br/web/index/izza";
//var urlSistema =  "http://52.86.148.125:8080/ClienteFiel/web/index/izza";

(function() {
	
	console.log('Iniciando izza.js');
	
	setTimeout(init,6000);

})();

function init() {
	window.serverMessage({ tipo: "init"});	
}


function mensagemFromBackground(data) {
	console.log("mensagemFromBackground -> " + JSON.stringify(data));

	if (data == null || data == undefined) {
		console.log("data is null -> mensagemFromBackground");
		return false;
	}

	switch(data.tipo) {
		  case "logado":
		    criarDivLogada();
		    break;
		  case "deslogado":
		    criarDivDesLogada();
		    break;
		  case "pausado":	  
		  	criarDivPausada();
		    break;
		  case "erro":
			console.log("erro: " + data);
		  	break;
		  case "text":
		  	enviarMensagem(data);
		    break;
		  case "script":
		  	executarScript(data);
		    break;
		  case "atualizar":
		  	window.location.href=window.location.href;
		    break;
		  case "aguardarmensagem":
		  	aguardarMensagem();
		  	break;
		  default:
		    console.log("outros: " + data);
	}
}

function aguardarMensagem() {
	window.WAPI.waitNewMessages(false,proccessMessage);
}

function executarScript(data) {
	console.log("Executando script do servidor." );	
	eval(data.mensagem);
}

function enviarMensagem(data) {
	window.WAPI.sendMessageToID(data.numeroCelular, data.mensagem);	
}

function criarDivPausada() {
	document.getElementById('divIzza').innerHTML = 'Izza Bot está com o envio de mensagens pausado.&nbsp;&nbsp; ';
	document.getElementById('divIzza').style.backgroundColor = '#f4b23b';
	var button = document.createElement('button');          
	var bText = document.createTextNode('Iniciar Atendimento');          
	button.appendChild(bText);        
	button.onclick = start;
	document.getElementById('divIzza').appendChild(button);
}

function criarDivLogada() {
	document.getElementById('divIzza').innerHTML = 'Izza Bot pronta para reponder às suas mensagens.&nbsp;&nbsp; ';
	document.getElementById('divIzza').style.backgroundColor = '#a237f487';
	var button = document.createElement('button');          
	var bText = document.createTextNode('Pausar Atendimento');          
	button.appendChild(bText);        
	button.onclick = pause;
	document.getElementById('divIzza').appendChild(button);
}

function criarDivDesLogada() {
	document.getElementById('divIzza').innerHTML = 'Izza Bot não conectada.&nbsp;&nbsp; ';
	document.getElementById('divIzza').style.backgroundColor = '#ff4d4d';
	var button = document.createElement('button');          
	var bText = document.createTextNode('Fazer Login ');   
	button.appendChild(bText);        
	button.onclick=login;
	document.getElementById('divIzza').appendChild(button);
}



function proccessMessage(data) {
	console.log('Mensagem recebida: '+ data.length);
	var i;
	for (i = 0; i < data.length; i++) { 
		window.serverMessage(data[i]);		
	}
}


function login() {
	//varWindow = window.open (urlSistema, 'popup');
 	window.open(urlSistema, "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,top=0,left=500,width=400,height=600");
}

function start() {
	window.serverMessage({ tipo: "start", chaveAcesso : ''});
	window.location.href=window.location.href
}

function pause() {
	window.serverMessage({ tipo: "pause", chaveAcesso : ''});
}

function logout(silent) {
	if (!silent) {
		if (confirm('Tem certeza que deseja desativar a Izza?')) {
			alert('Você parou a Izza!'); 
			window.serverMessage({tipo : "logout"});
		}
	} else {
		window.serverMessage({tipo : "logout"})
	}
}


function criarDivAcoes() {

	var div = document.createElement( 'div' );
	//set attributes for div
	div.id = 'divConfig';
	div.style.position = 'fixed';
	div.style.top = '0';
	div.style.left = '0';
	div.style.width = '100%';   
	div.style.height = '100%';
	div.style.backgroundColor = 'rgb(217, 207, 229)';
	div.style.color = 'white';
	div.style.display = 'none';
	div.style.zIndex = '99999999999999999999999999';
	
	div.innerHTML = 'Conectando....'	;


	var h3 =  document.createElement( 'H3' );
	h3.innerHTML = 'Disparo de Mensagens';
	h3.style.margin = '25px';
	div.appendChild(h3);


	var label1 =  document.createElement( 'label' );
	label1.innerHTML = '1. Texto da Mensagem';
	div.appendChild(label1);	

	var input =  document.createElement( 'textarea' );
	input.id = 'txtMensagem';
	input.placeHolder = 'Insira aqui a mensagem';
	div.appendChild(input);

	label =  document.createElement( 'label' );
	label.innerHTML = '2. Destinatários';
	div.appendChild(label);

	input =  document.createElement( 'textarea' );
	input.id = 'txtDestinos';
	input.placeHolder = 'Insira aqui os ´destinatários.';
	div.appendChild(input);

	var button = document.createElement('button');          
	var bText = document.createTextNode('Disparar');          
	button.appendChild(bText);        
	button.onclick = disparar;
	div.appendChild(button);	


	var caixa = document.getElementsByClassName('_3HZor _2rI9W')[1];
	caixa.insertBefore(div,caixa.firstChild);

}

function ocultarDivAcoes() {
	document.getElementById('divConfig').style.display = 'none';
}

function exibirDivAcoes() {
	document.getElementById('divConfig').style.display = 'inline';	
}

function disparar() {
	var mensagens = document.getElementById('txtMensagem');
	var numeros = document.getElementById('txtDestinos').value.split(",");

	var len = numeros.length; 
	for (var i = 0; i < len; i++)  {
		window.WAPI.sendMessageToID(numeros[i]+'@c.us', mensagens);
	}
	
	
}
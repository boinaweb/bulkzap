(function() {	
	
	try {
		// For receiving messages from WhatsApp
		var messageFromClient = function(data) {
			try {
				console.log(data);
				chrome.runtime.sendMessage(data);
			} catch(e) {
				console.log(e);
				window.location.href = window.location.href;
			}
		};
		
		// Constructing a new messaging DOM element
		var messaging = document.createElement("div");
		messaging.id = "whatsapp_messaging";
		
		// Attaching a listener for messages from WhatsApp
		messaging.addEventListener("whatsapp_message", function(e) {
			messageFromClient(e.detail);
		});
		
		// Injecting the element
		(document.head || document.documentElement).appendChild(messaging);
		
		// For sending messages to WhatsApp
		var clientMessage = function(data) {
			document.getElementById("whatsapp_messaging").dispatchEvent(new CustomEvent("content_message", { "detail": data }));
		};
		
		// Listening for messages from background script
		chrome.runtime.onMessage.addListener(function(request, sender) {
			if (!sender.tab) {
				// Message from background script
				clientMessage(request);			
			}
		});
		
		// Loading the API
		/*var el = document.createElement("script");
		el.src = chrome.extension.getURL("js/api.js");
		(document.head || document.documentElement).appendChild(el);*/

		console.log('Conectando...');

		//Criar div indicando whatsapp conectado

		var div = document.createElement( 'div' );
		//set attributes for div
		div.id = 'divIzza';
		div.style.position = 'fixed';
		div.style.top = '0';
		div.style.left = '0';
		div.style.width = '100%';   
		div.style.height = '20px';
		div.style.backgroundColor = 'red';
		div.style.color = 'white';
		div.style.zIndex = '99999999999999999999999999';
		div.innerHTML = 'Conectando....'	
		

		//append all elements
		document.body.appendChild( div );

		
		// Loading the WhatsBot script
		var el = document.createElement("script");
		el.src = chrome.extension.getURL("js/whatsapp.js");
		(document.head || document.documentElement).appendChild(el);

		/*var el = document.createElement("script");
		el.src = chrome.extension.getURL("js/wapi.js");
		(document.head || document.documentElement).appendChild(el);*/

		var el = document.createElement("script");
		el.src = chrome.extension.getURL("js/izza.js");
		(document.head || document.documentElement).appendChild(el);
	
	} catch(e) {
		console.log("Erro ao iniciar o script da izza - contente.js");
		window.location.href = window.location.href;
	}

})();	
		

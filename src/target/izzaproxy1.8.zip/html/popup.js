window.onload = function() {
	document.getElementById("verspan").innerHTML = chrome.runtime.getManifest().version;
	console.log('eventos definidos');
	document.getElementById('desconectar').addEventListener('click', logout());
	document.getElementById('conectar').addEventListener('click', login());
};

function login() {
	console.log('login');
	sessionStorage.setItem('chaveAcesso', '1212');
	document.getElementById('loginTxt').disabled = true;
	document.getElementById('senhaTxt').disabled = true;
	document.getElementById('conectar').style.display = 'none';
	document.getElementById('desconectar').style.display = 'block';
	window.href = window.href;
}

function logout() {
	console.log('logout');
	sessionStorage.setItem('chaveAcesso', null);
	document.getElementById('loginTxt').disabled = false;
	document.getElementById('senhaTxt').disabled = false;
	document.getElementById('conectar').style.display = 'block';
	document.getElementById('desconectar').style.display = 'none';
	window.href = window.href;
	
}
# IzzaProxy
Chat bot para integração da página web, web.whatsapp.com.br ao sistema do Cliente Fiel
Tutorial: https://docs.google.com/document/d/1IXD4pnmxGBmpU0-0z0dUQghncsHzD0aPqtIRHkrQkok
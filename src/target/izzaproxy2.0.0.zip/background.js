/*
This variable is responsible for keeping track of the active WhatsApp tab.
It is updated once the tab communicates with the background page (sends a type:start request)
*/

var dateNow = new Date;
var numeroJanela = -1;
var whatsapp_tab_id = -1;
var pedidos_aba_id = -1;
var chaveAutenticacao;
var urlDialogFlow = "https://us-central1-izza-lcmjrp.cloudfunctions.net/procIzzaSuporte"
var urlBase = "http://ws.appclientefiel.com.br/rest/";
var urlPedidos = "http://sistema.appclientefiel.com.br/web/controlepedidosfornecedor/ver";
var urlDominioSistema =  "http://sistema.appclientefiel.com.br";
//var urlBase = "http://52.86.148.125:8080/ClienteFiel/rest/";
//var audio = new Audio('https://clientefielsp.s3-sa-east-1.amazonaws.com/sons/ring.mp3');
var audio = new Audio(chrome.runtime.getURL("sounds/ring.mp3"));
let tempo_envio_mensagem_local = 10;


//quando inicia ele busca informações importantes
//1° qual numero do whatsapp logado
//2° quais os numeros de funcionarios da cliente fiel
var izza = false
var alertados_ForaDoHorario = [];




chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
	console.log("\n\n\n------------------------------------inicio-----------------------------------------------")

	switch(request.type){
		case "button_openTabPedido":
			abrirAbaPedidos();
			break;
		case "button_openTabWhatsapp":
			abrirAbaWhatsapp();
			break;
	}
});



chrome.notifications.onButtonClicked.addListener(acaoBotoes);

chrome.runtime.onStartup.addListener(function () {
	console.log("Plugin Startup");			

});

chrome.runtime.onInstalled.addListener(function () {
	console.log("Plugin instalado");
	 inicializarTabs();
	//setTimeout(inicializarTabs, 5000);
});


function inicializarTabs() {
	whatsapp_tab_id = -1;
	pedidos_aba_id = -1;
	numeroJanela = -1;
	var abas = new Array();

	chrome.windows.getCurrent(function(win) {
    	chrome.tabs.getAllInWindow(win.id, function(tabs) {
	        abas = tabs;
			console.debug(abas);

			var i;
			for (i = 0; i < abas.length; i++) {
				var aba = abas[i];
			    if (~aba.url.indexOf("web.whatsapp.com")) {
			    	whatsapp_tab_id = aba.id;
			    }

			    if (~aba.url.indexOf("sistema.appclientefiel.com.br")) {
			    	pedidos_aba_id = aba.id;
			    }
		  	}

		  	if (pedidos_aba_id == -1) {
				chrome.tabs.create({ url: urlDominioSistema, index : 0 });	
				pedidos_aba_id = 0;			
			} else {
				chrome.tabs.update(pedidos_aba_id,{url: urlDominioSistema});
			}

			if (whatsapp_tab_id == -1) {
				chrome.tabs.create({ url: 'https://web.whatsapp.com/', index : 1});
			} else {
				chrome.tabs.update(whatsapp_tab_id,{url:"https://web.whatsapp.com"});
			}

		});
	});
}
 

chrome.webNavigation.onCompleted.addListener(function(details) {

	/*Adiciona os scripts na página do whatsapp*/
	if (~details.url.indexOf("https://web.whatsapp.com/")) {
		console.log("Abriu a página web.whatsapp.com");	
		whatsapp_tab_id = details.tabId;
		chrome.tabs.executeScript(details.tabId, {file: "js/content.js"});
	}

	if (~details.url.indexOf("pedidosfornecedor")) {
		console.log("Abriu a página de recebimento dos pedidos");	
		pedidos_aba_id = details.tabId;
	}

	/*Obtém o cookie da página do cliente fiel*/
	if (~details.url.indexOf("52.86.148.125") || ~details.url.indexOf("sistema.appclientefiel.com.br")) {
		console.log("Abriu a página sistema.appclientefiel.com.br" );	
		if (whatsapp_tab_id != -1) {
			getCookieIZZA();
		} else {
			console.log('Página do whatsapp ainda não aberta.')
		}
	}

	
});


function removeCookieIZZA() {
	chrome.cookies.remove({"url": urlDominioSistema, "name": "CHAVEIZZAONLINE"}, function(cookie) {
        console.log("cookie removido: " + cookie)
    });
}

function getCookieIZZA() {
    chrome.cookies.get({"url": urlDominioSistema, "name": "CHAVEIZZAONLINE"}, function(cookie) {
	        if (cookie) {
		        ID = cookie.value;
		        var chaveAtual = localStorage.getItem('chaveAcesso');
		        console.log("chave salva:" + chaveAtual);
		        console.log("cookie lido:" + ID);
		        /*Caso a chave do cookie seja diferente da atual, atualiza a chave e reinicia a página do whatsapp*/
		        if (chaveAtual == null || chaveAtual != ID) {
		        	localStorage.setItem('chaveAcesso', ID);	
		        	clientMessage({tipo : "atualizar"});
		        }
		      }
	 });
}


/*
Passes a message to the client (dict-obj)
Full journey from here - to content script, then to the webpage through the DOM
*/
function clientMessage(data) {
	//console.log("clientMessage: ", JSON.stringify(data));
	chrome.tabs.sendMessage(whatsapp_tab_id, data);
}

/*
Listening to messages from the content script (webpage -> content script -> *backgrund page* -> host)
*/
chrome.runtime.onMessage.addListener(function(data, sender) {
	
	if (sender.tab) {
		
		switch(data.tipo) {
		  case "init":
		    console.log('Init recebido da página do whatsapp');
		    init();
		    break;
		  case "logout":
		    console.log('Logout recebido da página do whatsapp');
		    logout();
		    break;
		  case "start":
		  	console.log('Start recebido da página do whatsapp');
		    start();
		    break;
		  case "pause":
		    console.log('Pause recebido da página do whatsapp');
		    pause();
		    break;
		  default:
		    processMessage(data);
		}
	}
});

function isLoggedActive() {
	return localStorage.getItem('chaveAcesso') != null && localStorage.getItem('pause') == null;
}

function isLogged() {
	return localStorage.getItem('chaveAcesso') != null;
}

function requestServerPost(obj, path) {
	var ajax = new XMLHttpRequest();
	var url = urlBase + path;

	ajax.open("POST", url, true);
	ajax.setRequestHeader("Access-Control-Allow-Origin", "*");
	ajax.setRequestHeader("Access-Control-Allow-Headers", "Content-type");
	ajax.setRequestHeader("Content-type", "application/json");
	ajax.setRequestHeader("Authorization", "Basic " + localStorage.getItem('chaveAcesso'));
	ajax.send(JSON.stringify(obj));

	// Cria um evento para receber o retorno.
	ajax.onreadystatechange = function() {
	  // Caso o state seja 4 e o http.status for 200, é porque a requisiçõe deu certo.
	  
		if (ajax.readyState == 4) {
			if (ajax.status == 200) {
				var data = JSON.parse(ajax.responseText);			    
				console.log('Mensagem enviada ao servidor: ' + obj.idMensagem);
			    clientMessage(data);
			} else if (ajax.status == 401) {
				console.log('Chamando logout.');
				logout();	
			} else {
				console.log("Status:" + ajax.status);
				clientMessage(data);
			}
		} 
	}	
}


function cheksIsNotNull(obj) {
  return obj !== null && obj !== undefined
}

function getNewLocalMessages(){
	if (isLoggedActive()) {
		var item = localStorage.getItem('lastMessage');
		var lastMessage = JSON.parse(item);
		if(lastMessage !== null && lastMessage !== undefined && lastMessage.lista !== null && lastMessage.lista !== undefined && lastMessage.lista.length !== 0){

			
			var novaLista = lastMessage.lista;
			
			var restantes = lastMessage.lista.map(function(obj){

				if(obj !== null){

					let currentDate = new Date();
					let lastMessageDate = new Date(obj.data_last_message);

					let difference = (currentDate - lastMessageDate) / 1000;
					
					if(difference >= tempo_envio_mensagem_local){
						var mensagens = obj.listObj.map(function(item){
							return  item.mensagem;
						});

						var texto = "";
						for(var i = 0 ; i < mensagens.length ; i++){
							texto += mensagens[i] + " ";
						}


						console.log("ENVIANDO MENSAGEM: " + texto);

						var objToRequest = obj.listObj[0];
						objToRequest.mensagem = texto;

						requestServerPost(objToRequest, 'bot/RegistrarMensagem');
						return null;
					}else{
						console.log("-- VAI ENVIAR em: " + (tempo_envio_mensagem_local -  parseInt(difference)) + " SEGUNDOS -> ");
						return obj;
					}
				}
				
			});

			if(restantes !== null && restantes !== undefined && restantes.length !== 0){
				for(var i = 0 ; i < restantes.length ; i ++){
					var item = restantes[i];
					if(item === null || item === undefined){
						restantes.splice(i,1);
					}
				}
			}else{
				restantes = [];
			}
			
			console.log("Clientes na Fila de Envio:  " + restantes);
			lastMessage.lista = restantes;
			localStorage.setItem('lastMessage', JSON.stringify(lastMessage));
			
		}else{
			//console.log("NADA A ENVIAR");
		}
	}
	setTimeout(getNewLocalMessages,2000);
}

function createLista(obj, lastMessage){
	let numeroCelular = obj.numeroCelular;
	lastMessage = {lista : [{
				telefone: numeroCelular,
				listObj: [obj],
				data_last_message: new Date()
			}]};

	localStorage.setItem('lastMessage', JSON.stringify(lastMessage));
	console.log("MENSAGEM INSERIDA - INIT");

}

function addMessageToNewNumber(obj, listaMaster){
	let numeroCelular = obj.numeroCelular;
	var listLastMessage = listaMaster.lista;
	
	var lastMessageSingle = {
			telefone: numeroCelular,
			listObj: [obj],
			data_last_message: new Date()
		};
	
	listLastMessage.push(lastMessageSingle); //importante ser //push

	listaMaster.lista = listLastMessage;
	localStorage.setItem('lastMessage', JSON.stringify(listaMaster));
	console.log("MENSAGEM INSERIDA -> Número NOVO");

}
function addMessageToNumber(obj, lastMessage){
	let numeroCelular = obj.numeroCelular;
	var listaMaster = JSON.parse(lastMessage);
	var listLastMessage = listaMaster.lista;

	var numberExist = false;
	for(var i = 0 ; i < listLastMessage.length ; i ++){
		var last = listLastMessage[i];	
		if(last.telefone === numeroCelular){
			
			var lista = last.listObj;
			lista.push(obj); //importante ser //push

			last.data_last_message = new Date();
			last.listObj = lista

			listLastMessage[i] = last;
			numberExist = true;
			break;
		}
	}

	if(!numberExist){
		addMessageToNewNumber(obj, listaMaster);
		return;
	}

	listaMaster.lista = listLastMessage;
	localStorage.setItem('lastMessage', JSON.stringify(listaMaster));
	console.log("MENSAGEM INSERIDA -> Número Existente");
}

function adicionarMensagemNaFila(obj){
	let numeroCelular = obj.numeroCelular;

	var lastMessage = localStorage.getItem('lastMessage');
	//console.log("VAMOS VER: " + lastMessage);
	if(lastMessage === [] || lastMessage === null || lastMessage === undefined || lastMessage.isEmpty || lastMessage.length === 0 ){
		createLista(obj, lastMessage);
	}else{
		addMessageToNumber(obj, lastMessage)
	}
}

function processMessage(data) {
	console.log("data: " + JSON.stringify(data))	

	izza = data.numeroWhatsLogado == '553196339065' || data.numeroWhatsLogado == '5531996339065'; 	
	//izza = data.numeroWhatsLogado == '553193861616' || data.numeroWhatsLogado == '5531993861616'; 	

	//verifica se whatsapp esta logado e se o numero do whatsapp logado é da izza				
	if (isLoggedActive()) {
		
		//verifica se chegou nulo a informações da mensagem
		if (data != null) {
			var obj = { 
			  "appNome"   :  "cliente_fiel", 
			  "numeroCelular"   :  data.chatId._serialized,
			  "mensagem"   :  data.content, 
			  "idMensagem"   :  data.id, 
			  "idRemetente"   :  data.to.user,
			  "nome" : data.sender.formattedName
			};

			var isSupport = obj.numeroCelular.includes("@g.us");

			console.log("Telefone: " + isSupport + obj.numeroCelular);
			console.log("izza: " + izza);

			if(izza && isSupport){
				//verifica se o numero da mensagem é de algum funcionario				
				console.log("é suporte")
				if(!data.numerosFuncionarios.includes(obj.idRemetente.split("@")[0])){	

					console.log("***MENSAGEM DE CLIENTE***" + "\n\nmensagem recebida:" + JSON.stringify(data))
					
					dateNow = new Date();			
					let horarioSuportStart = 10
					let horarioSuportEnd = 21
					
					if(dateNow.getHours() < horarioSuportStart 
						|| dateNow.getHours() >= horarioSuportEnd){ //FORA DO HORARIO

						console.log("***FORA DO HORARIO*** >> " + JSON.stringify(data.chatId._serialized))
						
						if(data.content.toLowerCase().includes("urgente") || data.content.toLowerCase().includes("urgentimente")){
							
							//console.log("É urgente e avisei no grupo cliente fiel")
							sendMessage("Avisei para os nossos atendentes que você precisa de suporte com urgência. Em breve você será atendido!", data.chatId._serialized)
							sendMessage("*" + data.sender.formattedName + "* Precisa de suporte urgente!", "553193058276-1449088203@g.us")
						
						}else if(!JSON.stringify(alertados_ForaDoHorario).includes(data.chatId._serialized)){
							console.log("Data: " + data.chatId._serialized);
							//console.log("Nao é urgente e avisei do horario de atendimento")
							var mensagemForaHorario = "Nosso horário de atendimento é de " + horarioSuportStart + "h às " + horarioSuportEnd + "h de segunda a sexta-feira."
							mensagemForaHorario += "\n";
							mensagemForaHorario += "Aos finais de semana atuamos em modo plantão atendendo demandas emergenciais.";
							mensagemForaHorario += "\n\n";
							mensagemForaHorario += "Deixe a sua mensagem e vamos responder o mais breve possível.";
							mensagemForaHorario += "\n";
							mensagemForaHorario += "Caso o seu aplicativo esteja fora de operação, inclua a palava URGENTE em sua mensagem.";
							mensagemForaHorario += "\n\n";
							mensagemForaHorario += "Você também pode consultar https://blog.appclientefiel.com.br/p/wiki.html ";
							mensagemForaHorario += "para ajudar em dúvidas ou problemas."
							//sendMessage("*Horário de Atendimento:* 10h às 21h (segunda - sexta) e modo plantão nos finais de semana. \n\nCaso o seu aplicativo esteja fora de operação, inclua a palava *URGENTE* em sua mensagem. \n\nConsulte https://blog.appclientefiel.com.br/p/wiki.html para ajudar em dúvidas ou problemas.", data.chatId._serialized);
							sendMessage(mensagemForaHorario, data.chatId._serialized);
							
							//adiciona como ja avisado fora de horario
							alertados_ForaDoHorario.push(data.sender.formattedName + " | " + data.chatId._serialized)
						}
						console.log("------------------------------------fim-----------------------------------------------\n\n")					
					}else{	//DENTRO DO HORARIO
						
						console.log("***DENTRO DO HORARIO*** >> " + JSON.stringify(data.chatId._serialized))
						
						//apaga todos que ja avisamos de fora de horario
						alertados_ForaDoHorario = []

						if(data.content.toLowerCase().includes("urgente") || data.content.toLowerCase().includes("urgentimente")){
							console.log("URGENTE: alertei funcionarios")
							sendMessage("Avisei para os atendentes que você precisa de um suporte com urgência. Aguarde o contato deles!", data.chatId._serialized);
							sendMessage("*" + data.sender.formattedName + "* Precisa de suporte urgente!", "553193058276-1449088203@g.us");
							console.log("------------------------------------fim-----------------------------------------------\n\n")
						}					
					}		
				}else{
					console.log("***MENSAGEM DE FUNCIONARIO(A) - Cliente Fiel***")
					console.log("------------------------------------fim-----------------------------------------------\n\n")
				}
				
				
				//porque este codigo, já que não vai responder?
				//sessao?
				//manda para dialogflow, porque??
				urlAtualDialogFlow = urlDialogFlow + "?message=" + data.content + "&session=" + data.chatId._serialized
				$.ajax({
					url: urlAtualDialogFlow,
					success: function(data) {    
						console.log("successo DIALOGFLOW: " + JSON.stringify(data));
					},
					beforeSend: function(){
							//console.log("beforeSend");
					},
					error: function (xhr, ajaxOptions, thrownError) {
							console.log("erro DIALOGFLOW");
					},
					complete: function(){
						console.log("------------------------------------fim-----------------------------------------------\n\n")
					}
				})


			}else{
				//não é izza
				console.log("nao é suporte")
				adicionarMensagemNaFila(obj);
				//requestServerPost(obj, 'bot/RegistrarMensagem');
				//serviço
				//getNewMessageLocal() // irá enviar as mensagens
			}
		} else {
			console.log('processMessage data nulo: ' + data );
			console.log("------------------------------------fim-----------------------------------------------\n\n")
		}
	}
}


function sendMessage(mensagem, remetente){
	//var json = {"tipo" : "text", "numeroCelular" : "5531973306335@c.us", "mensagem" : mensagem};
	var json = {"tipo" : "text", "numeroCelular" : remetente, "mensagem" : mensagem};
	clientMessage(json);
}

function init() {
	if (localStorage.getItem('chaveAcesso') != null && localStorage.getItem('pause') == null) {
		clientMessage({tipo : "logado"});
		
		var ajax = new XMLHttpRequest();
		var url = urlBase + "bot/ScriptInicial";
			
		ajax.open("GET", url, true);
		ajax.setRequestHeader("Access-Control-Allow-Origin", "*");
		ajax.setRequestHeader("Access-Control-Allow-Headers", "Content-type");
		ajax.setRequestHeader("Content-type", "application/json");
		ajax.setRequestHeader("Authorization", "Basic " + localStorage.getItem('chaveAcesso'));
		ajax.send();

		// Cria um evento para receber o retorno.
		ajax.onreadystatechange = function() {
		  // Caso o state seja 4 e o http.status for 200, é porque a requisiçõe deu certo.
			if (ajax.readyState == 4) {
				if (ajax.status == 200) {
					var lista = JSON.parse(ajax.responseText);
					var i;
					for (i = 0 ; i < lista.length;  i++) {
						console.log(lista[i]);
						clientMessage(lista[i]);			
					}			    
				} else if (ajax.status == 401) {
					console.log('chamando logout');
					logout();	
				} else {
					console.log("Status:" + ajax.status);
				}
			}
		}	
		setTimeout(sendWaitMessage,5000);


	} else if (localStorage.getItem('chaveAcesso') != null && localStorage.getItem('pause') != null) {
		clientMessage({tipo : "pausado"});	
	} else {
		clientMessage({tipo : "deslogado"});
		waitLogin();
	}
}

function sendWaitMessage() {
	clientMessage({tipo : "aguardarmensagem"});
}

function waitLogin() {
	console.log("Aguardando login");
	
	try {
		getCookieIZZA();
		if (localStorage.getItem('chaveAcesso') != null) {
			console.log("Logado, atualizando tela.");
			clientMessage({tipo : "atualizar"});	
			return true;
		}
	}  catch(e) {
		console.log(e);
	}

	setTimeout(waitLogin,3000);
}

function start() {
	localStorage.removeItem('pause');
	clientMessage({tipo : "logado"});
}

function pause() {
	localStorage.setItem('pause', true);
	clientMessage({tipo : "pausado"});
}

function logout() {
	localStorage.removeItem('chaveAcesso');
	localStorage.removeItem("lastMessage");
	removeCookieIZZA();
	clientMessage({tipo : "deslogado"});
	waitLogin();
}



function getNewMessages() {
	try {
		if (isLoggedActive()) {
			console.log("Buscando Mensagens");
			//console.log('Buscando novas mensagens: ' + localStorage.getItem('chaveAcesso'));

			var ajax = new XMLHttpRequest();
			var url = urlBase + "bot/BuscarMensagem";
				
			ajax.open("GET", url, true);
			ajax.setRequestHeader("Content-type", "application/json");
			ajax.setRequestHeader("Authorization", "Basic " + localStorage.getItem('chaveAcesso'));
			ajax.send();

			// Cria um evento para receber o retorno.
			ajax.onreadystatechange = function() {
			  // Caso o state seja 4 e o http.status for 200, é porque a requisiçõe deu certo.
				if (ajax.readyState == 4) {
					if (ajax.status == 200) {
						var lista = JSON.parse(ajax.responseText);
						var i;
						for (i = 0 ; i < lista.length;  i++) {
							console.log(lista[i]);
							clientMessage(lista[i]);			
						}			    
					} else if (ajax.status == 401) {
						console.log('chamando logout');
						logout();	
					} else {
						console.log("Status:" + ajax.status);
					}
				}
			}	
		}
	} catch(e) {
		console.log(e);
	}

	setTimeout(getNewMessages, 5000);
}

function abrirAbaWhatsapp(){
	whatsapp_tab_id = -1;
	var abas = new Array();

	chrome.windows.getCurrent(function(win) {
    	chrome.tabs.getAllInWindow(win.id, function(tabs) {
	        abas = tabs;
			console.debug(abas);
			var i;
			for (i = 0; i < abas.length; i++) {
				var aba = abas[i];
			    if (~aba.url.indexOf("web.whatsapp.com")) {
			    	whatsapp_tab_id = aba.id;
			    }
			  }
		  	if (whatsapp_tab_id == -1) {
				chrome.tabs.create({ url: 'https://web.whatsapp.com/', index : 1}, function(abaId) {whatsapp_tab_id = abaId;});		
			} else {
				//força o foco na tela de pedidos
				chrome.tabs.get(whatsapp_tab_id, function(tab) {
					chrome.tabs.highlight({'tabs': tab.index}, function() {});
				})
			}

		});
	});
}

function abrirAbaPedidos() {
	pedidos_aba_id = -1;
	var abas = new Array();

	chrome.windows.getCurrent(function(win) {
    	chrome.tabs.getAllInWindow(win.id, function(tabs) {
	        abas = tabs;
			console.debug(abas);

			var i;
			for (i = 0; i < abas.length; i++) {
				var aba = abas[i];
			    if (~aba.url.indexOf("pedidosfornecedor")) {
			    	pedidos_aba_id = aba.id;
			    }
			  }
			  

		  	if (pedidos_aba_id == -1) {
				chrome.tabs.create({index : 0, windowId : win.id,  url: urlPedidos }, function(abaId) {pedidos_aba_id = abaId;});	
			} else {

				//força o foco na tela de pedidos
				chrome.tabs.get(pedidos_aba_id, function(tab) {
					chrome.tabs.highlight({'tabs': tab.index}, function() {});
				})
			}

		});
	});
}

function getNewPedidos() {
	try {
		if (isLogged()) {
			//console.log('Buscando novos pedidos: ' + localStorage.getItem('chaveAcesso'));			
			var ajax = new XMLHttpRequest();
			var url = urlBase + "integracao/eventspolling";	
			ajax.open("GET", url, true);
			ajax.setRequestHeader("Access-Control-Allow-Origin", "*");		
			ajax.setRequestHeader("Content-type", "application/json");
			ajax.setRequestHeader("Authorization", "Basic " + localStorage.getItem('chaveAcesso'));
			ajax.send();

			// Cria um evento para receber o retorno.
			ajax.onreadystatechange = function() {
			  // Caso o state seja 4 e o http.status for 200, é porque a requisiçõe deu certo.
				if (ajax.readyState == 4) {
					if (ajax.status == 200) {
						var lista = JSON.parse(ajax.responseText);
						var i;
						for (i = 0 ; i < lista.length;  i++) {
							var n = lista[i];
							
							if (n.code == 'PLACED' && n.statusPedido == 0) {
								abrirAbaPedidos();
								pausarSomNavegador();
								

								var options =  {
													type: 'basic',
													title: 'Você tem um novo pedido #' + n.correlationId,
													message: 'Aceite pela página de pedidos no navegador.',
													iconUrl: 'logo/32.png',
													buttons: [{title : 'ABRIR SISTEMA DE PEDIDOS'}]											
												};

								console.log(JSON.stringify(n));
								console.log("Solicitação: " + n.code + " Vias: " + n.QuantidadeVias + " ExigirConfirmacao: " + n.ExigirConfirmacao);
								//chrome.tabs.executeScript( pedidos_aba_id, {code:"document.getElementById('audiopedido').pause()"});
								
								  
								audio.play();
								console.log("Ativei som plugin")
								chrome.notifications.create('' + n.correlationId, options, function(data) {console.log('notify: ' + data);} );
							}
						}			    
					} else if (ajax.status == 401) {
						console.log('chamando logout');
						logout();	
					} else {
						console.log("Status:" + ajax.status);
					}
				}
			}	
		}
	} catch(e) {
		console.log(e);
	}

	setTimeout(getNewPedidos, 5000);
}



function permissaoNotificacao() {
	// Let's check if the browser supports notifications
	if (!("Notification" in window)) {
		console.log("Browser nao esta permitido para criar notificações")
	}
  
	// Let's check if the user is okay to get some notification
	else if (Notification.permission === "granted") {
	  // If it's okay let's create a notification
	  console.log("Permitido criar notificações")
	}
  
	// Otherwise, we need to ask the user for permission
	else if (Notification.permission !== 'denied') {
	  Notification.requestPermission(function (permission) {
		// If the user is okay, let's create a notification
		if (permission === "granted") {
			console.log("Se usuario der ok é permitido criar notificações")
		}
	  });
	}
  
	// At last, if the user already denied any notification, and you 
	// want to be respectful there is no need to bother them any more.
  }


function acaoBotoes(notificationId, buttonIndex) {
	console.log('SolicitacaoId: ' + notificationId);
	console.log('button: ' + buttonIndex);

	//envia script para a pagina.

	chrome.tabs.get(pedidos_aba_id, function(tab) {
		chrome.tabs.highlight({'tabs': tab.index}, function() {});
	})
	  
	//chrome.tabs.executeScript( pedidos_aba_id, {code:"aceitarImprimir(" + notificationId + ");"}, function(results){ console.log(results + "Aceitou pelo plugin"); });

	if (buttonIndex == 0) {
		console.log('clicou no primeiro botão');
	}

	if (buttonIndex == 1) {
		console.log('clicou no segundo botão');
	}
	
}

function pausarSomNavegador() {
	// pausa o som do navegador quando usado a izza
	pedidos_aba_id = -1;
	var abas = new Array();

	chrome.windows.getCurrent(function(win) {
    	chrome.tabs.getAllInWindow(win.id, function(tabs) {
	        abas = tabs;
			console.debug(abas);

			var i;
			for (i = 0; i < abas.length; i++) {
				var aba = abas[i];
			    if (~aba.url.indexOf("pedidosfornecedor")) {
			    	pedidos_aba_id = aba.id;
			    }
		  	}

		  	if (pedidos_aba_id >= -0) {
				chrome.tabs.executeScript(pedidos_aba_id,{
					code: "document.getElementById('audiopedido').src = '';document.getElementById('audiopedido').pause();"
				  });								  
				console.log("Pausei som navegador")
			} 

		});
	});
}

(function() {
	getNewMessages();
	getNewPedidos();	
	getNewLocalMessages();
})();

//verifica a permisao de notificacao
permissaoNotificacao()
/*
This variable is responsible for keeping track of the active WhatsApp tab.
It is updated once the tab communicates with the background page (sends a type:start request)
*/
var whatsapp_tab_id = -1;
var chaveAutenticacao;
var urlBase = "http://ws.appclientefiel.com.br/rest/";
//var urlBase = "http://52.86.148.125:8080/ClienteFiel/rest/";

/*
Injecting the content script into the WhatsApp webpage and reseting the connection settings to the host.
*/
chrome.webNavigation.onCompleted.addListener(function(details) {
	
	if (~details.url.indexOf("https://web.whatsapp.com/")) {
		console.log("Injecting");	
		
		whatsapp_tab_id = details.tabId;
		//console.log(whatsapp_tab_id);
		
		// Injecting the content script into the page.
		chrome.tabs.executeScript(details.tabId, {file: "js/content.js"});
	}
	
});

/*
Passes a message to the client (dict-obj)
Full journey from here - to content script, then to the webpage through the DOM
*/
function clientMessage(data) {
	//console.log("clientMessage: ", JSON.stringify(data));
	chrome.tabs.sendMessage(whatsapp_tab_id, data);
}

/*
Listening to messages from the content script (webpage -> content script -> *backgrund page* -> host)
*/
chrome.runtime.onMessage.addListener(function(data, sender) {
	
	if (sender.tab) {
		
		switch(data.tipo) {
		  case "login":
		    authServer(data)
		    break;
		  case "logout":
		    logoutServer();
		    break;
		  case "start":
		    start();
		    break;
		   case "stop":
		    stop();
		    break;
		  default:
		    processMessage(data);
		}
	}
});


function requestServerPost(obj, path) {
	var ajax = new XMLHttpRequest();
	var url = urlBase + path;

	ajax.open("POST", url, true);
	ajax.setRequestHeader("Content-type", "application/json");
	ajax.setRequestHeader("Authorization", "Basic " + localStorage.getItem('chaveAcesso'));
	ajax.send(JSON.stringify(obj));

	// Cria um evento para receber o retorno.
	ajax.onreadystatechange = function() {
	  // Caso o state seja 4 e o http.status for 200, é porque a requisiçõe deu certo.
	  console.log("ajax.status: " + ajax.status + "ajax.readyState: " +ajax.readyState );
		if (ajax.readyState == 4) {
			if (ajax.status == 200) {
				console.log(ajax.responseText);
				var data = JSON.parse(ajax.responseText);
			    
			    console.log("Tipo: " + data.tipo + " Mensagem: " + data.mensagem);

			    clientMessage(data);
			} else if (ajax.status == 401) {
				console.log('chamando logout');
				logoutServer();	
			} else {
				console.log("Status:" + ajax.status +  "Resposta: " + ajax.responseText);
				clientMessage(data);
			}
		} 
	}	
}

function processMessage(data) {
	if (data != null) {
		console.log(JSON.stringify(data));
		var obj = { 
		  "appNome"   :  "cliente_fiel", 
		  "numeroCelular"   :  data.chatId._serialized,
		  "mensagem"   :  data.content, 
		  "idMensagem"   :  data.id, 
		  "idRemetente"   :  data.to.user
		};
		console.log('processMessage: ' + obj );
		requestServerPost(obj, 'bot/RegistrarMensagem');
	} else {
		console.log('processMessage data nulo: ' + data );
	}
}

function authServer(data) {
	localStorage.setItem('chaveAcesso', data.chaveAcesso);	
	//conferir login e senha

	clientMessage({tipo : "login", chaveAcesso : data.chaveAcesso});
}

function start() {
	localStorage.removeItem('pause');
	clientMessage({tipo : "start"});
}

function stop() {
	localStorage.setItem('pause', true);
	clientMessage({tipo : "stop"});
}

function logoutServer() {
	localStorage.removeItem('chaveAcesso');
	clientMessage({tipo : "logout"});
}



function getNewMessages() {
	try {
		if (localStorage.getItem('chaveAcesso') != null && localStorage.getItem('pause') == null) {
			console.log('Buscando novas mensagens: ' + localStorage.getItem('chaveAcesso'));

			var ajax = new XMLHttpRequest();
			var url = urlBase + "bot/BuscarMensagem";
				
			ajax.open("GET", url, true);
			ajax.setRequestHeader("Content-type", "application/json");
			ajax.setRequestHeader("Authorization", "Basic " + localStorage.getItem('chaveAcesso'));
			ajax.send();

			// Cria um evento para receber o retorno.
			ajax.onreadystatechange = function() {
			  // Caso o state seja 4 e o http.status for 200, é porque a requisiçõe deu certo.
				if (ajax.readyState == 4) {
					if (ajax.status == 200) {
						var lista = JSON.parse(ajax.responseText);
						var i;
						for (i = 0 ; i < lista.length;  i++) {
							clientMessage(lista[i]);			
						}			    
					} else if (ajax.status == 401) {
						console.log('chamando logout');
						logoutServer();	
					} else {
						console.log("Status:" + ajax.status +  "Resposta: " + ajax.responseText);
					}
				}
			}	
		}
	} catch(e) {
		console.log(e);
	}

	setTimeout(getNewMessages, 4000);
}



(function() {
	getNewMessages();
})();

var varWindow;
var urlSistema =  "http://sistema.appclientefiel.com.br/web/index/izza";
//var urlSistema =  "http://52.86.148.125:8080/ClienteFiel/web/index/izza";

(function() {
	
	console.log('Iniciando izza.js');
	
	setTimeout(init,3000);

})();

function init() {
	window.serverMessage({ tipo: "init"});
	aguardarMensagem();
}


function mensagemFromBackground(data) {
	console.log("mensagemFromBackground -> " + JSON.stringify(data));

	if (data == null || data == undefined) {
		console.log("data is null -> mensagemFromBackground");
		return false;
	}

	switch(data.tipo) {
		  case "logado":
		    criarDivLogada();
		    break;
		  case "deslogado":
		    criarDivDesLogada();
		    break;
		  case "pausado":	  
		  	criarDivPausada();
		    break;
		  case "erro":
			console.log("erro: " + data);
		  	break;
		  case "text":
		  	enviarMensagem(data);
		    break;
		  case "script":
		  	executarScript(data);
		    break;
		  case "atualizar":
		  	window.location.href=window.location.href;
		    break;
		  default:
		    console.log("outros: " + data);
	}
}

function aguardarMensagem() {
	window.WAPI.waitNewMessages(false,proccessMessage);
}

function executarScript(data) {
	console.log("Executando script: " + data.mensagem);	
	eval(data.mensagem);
}

function enviarMensagem(data) {
	window.WAPI.sendMessageToID(data.numeroCelular, data.mensagem);	
}

function criarDivPausada() {
	document.getElementById('divIzza').innerHTML = 'Izza Bot está com o envio de mensagens pausado.&nbsp;&nbsp; ';
	document.getElementById('divIzza').style.backgroundColor = '#f4b23b';
	var button = document.createElement('button');          
	var bText = document.createTextNode('Iniciar Atendimento');          
	button.appendChild(bText);        
	button.onclick = start;
	document.getElementById('divIzza').appendChild(button);
}

function criarDivLogada() {
	document.getElementById('divIzza').innerHTML = 'Izza Bot pronta para reponder às suas mensagens.&nbsp;&nbsp; ';
	document.getElementById('divIzza').style.backgroundColor = '#a237f487';
	var button = document.createElement('button');          
	var bText = document.createTextNode('Pausar Atendimento');          
	button.appendChild(bText);        
	button.onclick = pause;
	document.getElementById('divIzza').appendChild(button);
}

function criarDivDesLogada() {
	document.getElementById('divIzza').innerHTML = 'Izza Bot não conectada.&nbsp;&nbsp; ';
	document.getElementById('divIzza').style.backgroundColor = '#ff4d4d';
	var button = document.createElement('button');          
	var bText = document.createTextNode('Fazer Login ');   
	button.appendChild(bText);        
	button.onclick=login;
	document.getElementById('divIzza').appendChild(button);
}



function proccessMessage(data) {
	console.log('Mensagem recebida: '+ data.length);

	if (localStorage.getItem('chaveAcesso') != null) {
		var i;
		for (i = 0; i < data.length; i++) { 
			window.serverMessage(data[i]);		
		}
	}
}


function login() {
	//varWindow = window.open (urlSistema, 'popup');
 	window.open(urlSistema, "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,top=0,left=500,width=400,height=600");
}

function start() {
	window.serverMessage({ tipo: "start", chaveAcesso : ''});
	window.location.href=window.location.href
}

function pause() {
	window.serverMessage({ tipo: "pause", chaveAcesso : ''});
}

function logout(silent) {
	if (!silent) {
		if (confirm('Tem certeza que deseja desativar a Izza?')) {
			alert('Você parou a Izza!'); 
			window.serverMessage({tipo : "logout"});
		}
	} else {
		window.serverMessage({tipo : "logout"})
	}
}